<?php
/**
 * Title: Template Front Page
 * Slug: template-front-page
 * Categories: template
 * Inserter: false
 */

require __DIR__ . '/hero-default.php';
require __DIR__ . '/feature-brands.php';
require __DIR__ . '/banner-marquee.php';
require __DIR__ . '/feature-services.php';
require __DIR__ . '/feature-images.php';
require __DIR__ . '/feature-solutions.php';
require __DIR__ . '/stats-counter.php';
require __DIR__ . '/banner-footer.php';
require __DIR__ . '/cta-horizontal.php';

